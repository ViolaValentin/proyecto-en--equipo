from flask import Flask, render_template
from markupsafe import escape

app=Flask(__name__)
@app.get ("/")
def home():
    return render_template ("home.html") 

@app.get ("/productos")
def get_all_productos():
    return render_template("productos.html")

@app.get ("/productos/<id>")
def get_producto(id):
    producto=producto[id]
    return render_template ("prodcutos.html", id=id, producto=producto)

